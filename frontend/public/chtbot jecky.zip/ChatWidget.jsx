import { useState, useRef, useEffect } from "react";
import "./ChatWidget.css";

// ===== EDIT THESE: sample places. Replace with real JEC buildings, floors and directions. =====
const PLACES = [
  { n: "Computer Lab", a: ["computer lab", "cse lab", "lab"], w: "CSE Department, 1st floor",
    s: ["Enter through the main gate", "Walk straight to the CSE block", "Take the stairs to the 1st floor", "The lab is on your right"] },
  { n: "Library", a: ["library", "books"], w: "Central Library, ground floor",
    s: ["Enter through the main gate", "Turn left at the first junction", "The library is the building ahead"] },
  { n: "Admin Office", a: ["admin office", "office"], w: "Administrative Building, ground floor",
    s: ["Enter through the main gate", "Walk straight for about two minutes", "The office is the first building on your left"] },
];

const QUESTIONS = [
  "What is JECKY?",
  "Will today’s class be held?",
  "Where is the computer lab?",
  "Where do I find notes?",
  "What events are coming up?",
  "How do I contact the HoD?",
];

const DEMO = [
  ["9:00 AM", "Data Structures", "On", "ok"],
  ["10:00 AM", "Mathematics", "Cancelled", "no"],
  ["11:00 AM", "Digital Electronics", "Moved to 2 PM", "mid"],
];

const TEXT = {
  about: "JECKY is one smart platform for Jorhat Engineering College: a live timetable, notes, events, clubs, a faculty directory and this AI campus guide, all in one place instead of scattered WhatsApp chats.",
  cls: "Check the live timetable. When a teacher edits or cancels a class, you see it instantly, so there’s no need to message the teacher or the CR. Here’s how it looks (demo data):",
  notes: "Open the Notes section. Teachers upload study material for their classes, and you can download it from there, organised by class.",
  events: "Upcoming events appear right on the JECKY homepage. Club admins and faculty members post them, so every notice reaches the whole college in one place.",
  clubs: "The Clubs section lists every club with its description and member list, so you can discover clubs and approach their members easily.",
  contact: "The Faculty Directory has contact details for important faculty members and the Head of Department, all in one place.",
  roles: "Access depends on your role. Teachers edit or cancel their own classes and upload notes. Club admins and faculty members post events. Students view everything and ask this guide. Administrators publish verified information.",
  none: "I’m still learning that one. Try a question below, or ask about the timetable, notes, events, clubs, faculty contacts or a place on campus.",
};

const INTENTS = [
  ["about", ["jecky", "what is", "about", "platform", "who are you"]],
  ["cls", ["class", "held", "cancel", "timetable", "schedule", "lecture"]],
  ["roles", ["who can", "permission", "role", "access", "post"]],
  ["notes", ["note", "material", "study", "download"]],
  ["events", ["event", "fest", "upcoming", "notice", "happening"]],
  ["clubs", ["club", "join", "society"]],
  ["contact", ["hod", "contact", "faculty", "professor", "teacher", "phone", "head of"]],
];

const has = (l, k) => new RegExp("\\b" + k.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).test(l);

// Later, replace this function with: fetch("/api/chat", { method: "POST", ... })
function getAnswer(input) {
  const l = input.toLowerCase().trim();
  if (/^(hi|hello|hey)\b/.test(l))
    return { text: "Hi! Ask me about classes, notes, events, clubs or where something is on campus." };
  const place = PLACES.find((p) => p.a.some((a) => has(l, a)));
  if (place) return { text: `Here’s how to reach the ${place.n}:`, place };
  let best = null, top = 0;
  INTENTS.forEach(([key, words]) => {
    const n = words.filter((k) => has(l, k)).length;
    if (n > top) { top = n; best = key; }
  });
  if (!best) return { text: TEXT.none };
  return { text: TEXT[best], table: best === "cls" };
}

export default function ChatWidget() {
  const [open, setOpen] = useState(false);
  const [typing, setTyping] = useState(false);
  const [text, setText] = useState("");
  const [msgs, setMsgs] = useState([
    { who: "b", text: "Hi! I’m the JECKY campus guide. Ask me something, or tap a question below." },
  ]);
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ block: "end" });
  }, [msgs, typing, open]);

  function ask(s) {
    s = s.trim();
    if (!s || typing) return;
    setMsgs((m) => [...m, { who: "u", text: s }]);
    setTyping(true);
    setTimeout(() => {
      setMsgs((m) => [...m, { who: "b", ...getAnswer(s) }]);
      setTyping(false);
    }, 650);
  }

  function onSubmit(e) {
    e.preventDefault();
    ask(text);
    setText("");
  }

  return (
    <div className="jk-root">
      {open && (
        <section className="jk-panel" aria-label="JECKY campus guide">
          <header className="jk-head">
            <div className="jk-av">J</div>
            <div>
              <h2>JECKY Campus Guide</h2>
              <p>Ask about classes, notes, events and places</p>
            </div>
            <button type="button" className="jk-x" onClick={() => setOpen(false)} aria-label="Close chat">×</button>
          </header>

          <div className="jk-log" aria-live="polite">
            {msgs.map((m, i) => (
              <div key={i} className={`jk-m jk-${m.who}`}>
                <p>{m.text}</p>
                {m.table && (
                  <div className="jk-card">
                    {DEMO.map((r) => (
                      <div className="jk-row" key={r[0]}>
                        <span>{r[0]}</span><span>{r[1]}</span><span className={`jk-st ${r[3]}`}>{r[2]}</span>
                      </div>
                    ))}
                  </div>
                )}
                {m.place && (
                  <div className="jk-card">
                    <div className="jk-hd"><b>{m.place.n}</b> · {m.place.w}</div>
                    <ol>{m.place.s.map((s) => <li key={s}>{s}</li>)}</ol>
                  </div>
                )}
              </div>
            ))}
            {typing && (
              <div className="jk-m jk-b"><span className="jk-dots"><i /><i /><i /></span></div>
            )}
            <div ref={endRef} />
          </div>

          <div className="jk-chips">
            {QUESTIONS.map((q) => (
              <button type="button" key={q} onClick={() => ask(q)}>{q}</button>
            ))}
          </div>

          <div className="jk-form">
            <input value={text} onChange={(e) => setText(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && onSubmit(e)}
              placeholder="Ask a question…" aria-label="Your question" />
            <button type="button" onClick={onSubmit}>Send</button>
          </div>
        </section>
      )}

      <button type="button" className="jk-fab" onClick={() => setOpen((o) => !o)}
        aria-label={open ? "Close campus guide" : "Open campus guide"}>
        {open ? "×" : "Ask JECKY"}
      </button>
    </div>
  );
}
